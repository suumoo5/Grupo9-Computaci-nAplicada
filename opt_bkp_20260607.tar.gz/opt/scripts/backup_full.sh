#1bin/bash

if [[ $1 == "-help" ]]; then
	echo "+##########################################+"
	echo "| Script de Backup - AYUDA -               |"
	echo "+##########################################+"
	echo "|                                          |"
	echo "| Uso: ./backup_full.sh (origen) (destino) |"
	echo "|                                          |"
	echo "| El archivo generado tendra el formato:   |"
	echo "| <nombre>_bkp_YYYYMMDD.tar.gz             |"
	echo "|						 |"
	echo "+##########################################+"
	exit 0
fi

ORIGEN=$1
DESTINO=$2

if [[ $# -ne 2 ]]; then
	echo "ERROR: Debe indicar un ORIGEN y DESTINO."
	echo "Si necesita ayuda, use: ./backup_full.sh -help"
	exit 1
fi

if [[ ! -d $ORIGEN ]]; then
	echo "ERROR: El directorio de origen $ORIGEN no existe."
	exit 1
fi

if [[ ! -d $DESTINO ]]; then
	echo "ERROR: El directorio de destino $DESTINO no existe."
	exit 1
fi

FECHA=$(date +%Y%m%d)
NOMBRE=$(basename $ORIGEN)

ARCHIVO="${NOMBRE}_bkp_${FECHA}.tar.gz"

tar -czf $DESTINO/$ARCHIVO $ORIGEN
echo "Backup realizado: $DESTINO/$ARCHIVO"
